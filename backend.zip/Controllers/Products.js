const Product = require('../models/Products');


 async function addProducts(req, res) {
    try {
      const product = new Product(req.body);
      const savedProduct = await product.save();
      res.status(201).json({
        message: 'Product added successfully',
        product: savedProduct,
      });
    } catch (error) {
      res.status(500).json({ message: 'Error adding product', error });
    }
  }
  async function getAllProducts(req, res){
    try {
      const products = await Product.find();
      res.status(200).json(products);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching products', error });
    }
  }

async function getSingleProduct(req, res) {
  const productsid = req.params.id;

  try {
    const product = await Product.findById(productsid);
    if (!product) {
      return res.status(404).json({ error: 'Job posting not found' });
    }

    res.json(product);
  } catch (error) {
    console.error('Error fetching single job posting:', error);
    res.status(500).json({ error: 'Error fetching single job posting' });
  }
}


module.exports = {
  addProducts,
  getAllProducts,
  getSingleProduct
};
