const express = require('express');
const router = express.Router();
const {addProducts, getAllProducts,getSingleProduct}=require('../Controllers/Products')
router.post('/products', addProducts);
  
  // GET route to fetch all products
  router.get('/products',getAllProducts );
  router.get('/products/:id',getSingleProduct);


module.exports = router;