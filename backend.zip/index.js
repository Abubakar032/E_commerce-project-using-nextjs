// Import required modules
require("dotenv").config();
const express = require("express");
const app = express();
const cors = require("cors");
const connection = require("./db");
const Products =require("./routes/Products");
// Middleware setup
app.use(express.json());
app.use(cors());
app.use(express.static('public'));

connection();



// Define API routes
app.use("/api", Products);



const port = process.env.PORT || 6363;


app.listen(port, () => {
  console.log(`Listening on port ${port}...`);
});
