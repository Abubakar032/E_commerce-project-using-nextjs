const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  id: String,
  name: String,
  company: String,
  price: Number,
  image:String,
  colors: [String],
  description: String,
  category: String,
  featured: Boolean,
  stock: Number,
  reviews: Number,
  stars: Number,
  images: [
    {
      id: String,
      width: Number,
      height: Number,
      url: String,
    },
  ],
  shipping: Boolean,
});

const Product = mongoose.model('Product', productSchema);


module.exports = Product;


